// ava
const test = require('ava');

// test
test.serial('test', (t) => {
  t.pass();
});
