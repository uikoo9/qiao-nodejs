## $project

[![npm version](https://img.shields.io/npm/v/$project.svg?style=flat-square)](https://www.npmjs.org/package/$project)
[![npm downloads](https://img.shields.io/npm/dm/$project.svg?style=flat-square)](https://npm-stat.com/charts.html?package=$project)
